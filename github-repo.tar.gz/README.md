# 1863 Fernandez Juncos #804 — San Juan, PR

For Sale by Owner listing page.

## How to use
1. Upload this folder to a GitHub repository.
2. Enable GitHub Pages (Settings → Pages → Deploy from branch → main / root).
3. The site will be live at `https://yourusername.github.io/repo-name/`.

## Files
- `index.html` — main listing page
- `photos/` — property photos

Contact: (214) 402-1577
